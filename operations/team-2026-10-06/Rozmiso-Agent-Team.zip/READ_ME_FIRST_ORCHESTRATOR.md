# Start the Rozmiso team

Updated 6 October 2026. **Codex is the main orchestrator and the owner's single point of contact.**

1. Read TEAM_ROSTER_AND_RULES.md for hierarchy, departments and decisions.
2. Read team/TASK-BOARD.json for the current assignments and dependencies.
3. For Antigravity account A use team/prompts/ANTIGRAVITY-A.md. For account B use team/prompts/ANTIGRAVITY-B.md. Sign in directly; never put passwords or tokens in a prompt.
4. Return work in the assigned team/reports/<task-id>/ folder using team/templates/WORK-REPORT.md. Tell Codex which report is ready. Codex reviews and accepts it.

There are seven department heads and fourteen worker roles, plus Director planning support. These are reusable role definitions; they are not twenty-two permanently running agents. Start with Codex and two external task lanes and delegate only useful bounded work.

## Current source and evidence

- Store name: Rozmiso. Store URL: https://rozmiso.myshopify.com
- Theme source: F:/Dropshipping/rozmiso-studio-theme
- Latest documented launch snapshot: outputs/01a10c16-2853-7d31-beb1-8ba2ec9f15d6/LAUNCH-PREP-RESULTS.md
- Brand guide: outputs/01a10c16-2853-7d31-beb1-8ba2ec9f15d6/BRAND-GUIDE.md
- Owner setup guide: outputs/01a10c16-2853-7d31-beb1-8ba2ec9f15d6/START-HERE.md
- Integration details and honest status: team/ANTIGRAVITY-SETUP.md

The launch snapshot is a dated report, not a current live connection. Verify current stock, suppliers, payments, policies and shipping before enabling commerce. A professional storefront alone is not a functioning sales business.

## Legacy setup

Historical Open Dots service, database, model and deployment statements are unverified. This team setup does not restart services, reseed personas, run paid inference or connect any external account. Do not run old startup commands automatically.

The previous guide contained plaintext credentials. Credential-related lines were removed from the active guide and its historical copy. The owner must rotate/revoke the exposed NVIDIA credential and local owner token through their respective settings; these documents cannot revoke a credential. Do not paste replacement secrets into files or chat.

Historical copies are under operations/team-2026-10-06/legacy-redacted and must never be used as active prompts.
