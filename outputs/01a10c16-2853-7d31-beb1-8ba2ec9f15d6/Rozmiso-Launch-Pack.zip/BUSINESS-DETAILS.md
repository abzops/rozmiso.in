# Rozmiso business details

Fill these with real information. They are the inputs for policies and onboarding, not company-registration certificates.

| Field | Your answer |
|---|---|
| Store/brand name | Rozmiso |
| Legal seller name | To confirm |
| Seller structure and applicable registration | To confirm with an accountant |
| Public customer-support email | To choose and verify |
| Public customer-support telephone | To confirm |
| Principal business address and PIN | To confirm |
| Authorized return destination | To agree with supplier |
| Grievance contact and process | To confirm for applicable obligations |
| GST registration/tax treatment | To confirm with an accountant |
| Supplier contracting entity | To confirm |
| Shipping/handling costs and coverage | Awaiting quote |
| Dispatch/delivery estimate | Awaiting written terms |
| Customer return/cancellation rules | Awaiting confirmed operations and applicable requirements |
| Sample purchase budget | To choose |
| First advertising test budget | To choose |
| Dispatch/refund cash reserve | To choose |

Keep PAN, government ID, bank account numbers, passwords and OTPs out of this document. Submit them directly to the verified provider when requested.

